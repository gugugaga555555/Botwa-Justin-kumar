/*
  [ NOMER GANTI PAKE NO BOT KAMU ]
*/
global.owner = ['GANTI NOMER KAMU']
global.ownername = "JustinOfficial"
global.connect = true // False = QrCode
global.antilink = false
global.autotyping = true
global.welcome = false
global.autoreadsw = false
global.autorecord = true

/*
  [ PAYMENT BEBAS ]
*/
global.dana = "081572074859"
global.gopay = "081572074859"
global.ovo = "081572074859"
global.qris = "https://files.catbox.moe/wvdg0l.png"

/*
  [ GAUSAH DI UBAH ]
*/
global.mess = {
"ketua": "*[Justin V17]* Akses Di Tolak!",
"prem": "*[Justin V17]* Akses Di Tolak!",
"premium": "*[Justin V17]* Akses Di Tolak!",
"japost": "*[Justin V17]* Akses Di Tolak!",
"rekber": "*[Justin V17]* Akses Di Tolak!",
"owner": "*[Justin V17]* Akses Di Tolak!"
}

/*
  [ GAUSAH DI UBAH ]
*/
global.tele = "t.me/justinoffc"
global.tele2 = "t.me/justinoffc"
global.waMe = "wa.me/6281572074859"
global.tutorialBot = "https://youtube.com/@justinofficial-id"
global.versionofscript = "V17.0"
global.url = "https://files.catbox.moe/cx09ww.jpg"
global.urlbanner = "https://files.catbox.moe/cx09ww.jpg"
global.url2 = "https://t.me/justinoffc"
global.packname = "Stiker By"
global.author = "JustinOfficial"
global.group = "https://whatsapp.com/channel/0029VaxxUio545v2bL3FE91g"
global.idCH = "120363373003239606@newsletter"
global.xchannel = {
	jid: '120363373003239606@newsletter'
	}
	